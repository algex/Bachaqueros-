<html>
<head>
	<title>Enviado!</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/hola.css">
</head>
<body>
<h1>Gracias por tu denuncia. Las autoridades fueron informadas.</h1>
</body>
</html>