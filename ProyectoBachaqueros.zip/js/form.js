  $(document).ready(function() {
    Materialize.updateTextFields();
  });

$(document).ready(function() {
    $('input#input_text, textarea#textarea1').characterCounter();
  });